@ECHO OFF
SET APP_HOME=%~dp0
IF NOT EXIST "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" (
  ECHO Gradle Wrapper JAR is missing. Open this project in Android Studio and let Gradle sync/download the configured Gradle 8.9 distribution, or regenerate the wrapper with: gradle wrapper --gradle-version 8.9
  EXIT /B 1
)
java -classpath "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
