# Web files for launcher

Разместите `manifest.json` и APK игры в публичной папке вашего сайта/CDN.
После загрузки реального APK посчитайте SHA-256 и замените значение в manifest.json.
