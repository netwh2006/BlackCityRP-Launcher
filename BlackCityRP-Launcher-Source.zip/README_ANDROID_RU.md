# BlackCityRP Launcher — Android Studio project

Это подготовленный исходник простого Android-лаунчера BlackCityRP.

## Сейчас
- приложение называется **BlackCityRP**;
- package name: `com.blackcityrp.launcher`;
- версия: `1.0.0`;
- Android 8.0+ (API 26+);
- compile/target SDK 35;
- серверные URL оставлены заглушками — их можно добавить позже;
- проект использует Kotlin + Jetpack Compose;
- DownloadManager и установщик APK уже подготовлены на будущее.

## Открытие в Android Studio
1. Распакуйте архив.
2. Запустите Android Studio.
3. Нажмите **Open** и выберите папку `BlackCityRP_Android_Launcher_READY`.
4. Установите/выберите **JDK 17 или 21** в Gradle JDK.
5. Дождитесь Gradle Sync.
6. Если Android Studio предложит скачать Gradle 8.9 / Android SDK 35 — согласитесь.
7. Для APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
8. APK будет в `app/build/outputs/apk/debug/app-debug.apk`.

## Если нужен просто APK без сервера
Пока ничего на сервере настраивать не нужно. Лаунчер соберётся и установится как обычное Android-приложение. Проверка сервера и загрузка игры начнут работать после добавления URL в `MainActivity.kt`.

## Позже
В `app/src/main/java/com/blackcityrp/launcher/MainActivity.kt` можно заменить:
- `HEALTH_URL` — API состояния сервера;
- `MANIFEST_URL` — адрес `manifest.json`;
- `GAME_PACKAGE` — package name Unity-игры.

Формат `manifest.json`:
```json
{
  "version": "1.0.1",
  "versionCode": 2,
  "apkUrl": "https://example.com/BlackCityRP.apk",
  "sha256": "SHA256_64_HEX_SYMBOLS",
  "sizeMb": 650.0
}
```

## Важно
В исходном архиве не было `gradle-wrapper.jar`. Поэтому в проект добавлены `gradlew`, `gradlew.bat` и `gradle-wrapper.properties`; Android Studio сможет использовать указанную версию Gradle и при необходимости скачать её. Для обычного открытия проекта **Android Studio → Open** это достаточно; если IDE потребует регенерацию Wrapper, выполните `gradle wrapper --gradle-version 8.9`.
