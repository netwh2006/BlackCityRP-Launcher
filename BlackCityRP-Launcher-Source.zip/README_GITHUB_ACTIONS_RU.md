# BlackCityRP Launcher — сборка APK через GitHub Actions

Компьютер и Android Studio не нужны. Проект можно собрать на серверах GitHub.

## Как собрать APK с телефона

1. Создайте новый репозиторий на GitHub.
2. Загрузите содержимое этой папки в репозиторий.
3. В репозитории откройте **Actions**.
4. Выберите **Build BlackCityRP Launcher APK**.
5. Нажмите **Run workflow**.
6. После завершения откройте выполненный workflow.
7. Внизу страницы найдите **Artifacts** → **BlackCityRP-Launcher-APK**.
8. Скачайте архив и достаньте из него `BlackCityRP_Launcher-debug.apk`.

Также сборка запускается автоматически после push в `main` или `master`.

## Что пока не подключено

- реальный сервер BlackCityRP;
- production `manifest.json`;
- обновление игры с сервера;
- release-подпись.

Сейчас это обычная debug-сборка лаунчера для первого теста на Android.
