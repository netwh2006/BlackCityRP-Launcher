package com.blackcityrp.launcher

import android.app.DownloadManager
import android.content.*
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import org.json.JSONObject

object LauncherConfig {
    // Replace with your VPS domain/IP. HTTPS is recommended for production.
    const val HEALTH_URL = "http://YOUR_SERVER_IP:8080/health"
    const val MANIFEST_URL = "https://YOUR_DOMAIN/blackcityrp/manifest.json"
    const val GAME_PACKAGE = "com.blackcityrp.game"
    const val GAME_APK_NAME = "BlackCityRP.apk"
}

data class ServerState(val online: Boolean, val players: Int = 0, val maxPlayers: Int = 0, val text: String = "Нет связи")
data class GameManifest(val version: String, val versionCode: Int, val apkUrl: String, val sha256: String, val sizeMb: Double)

class MainActivity : ComponentActivity() {
    private var downloadId = -1L
    private var downloadedFile: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LauncherScreen() }
    }

    @Composable
    private fun LauncherScreen() {
        var server by remember { mutableStateOf(ServerState(false, text = "Проверка сервера…")) }
        var manifest by remember { mutableStateOf<GameManifest?>(null) }
        var message by remember { mutableStateOf("Готов к запуску") }
        var busy by remember { mutableStateOf(false) }

        LaunchedEffect(Unit) {
            server = fetchServer()
            manifest = fetchManifest()
            message = if (server.online) "Сервер доступен" else "Сервер недоступен"
        }

        MaterialTheme {
            Surface(Modifier.fillMaxSize()) {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Spacer(Modifier.height(30.dp))
                    Text("BLACKCITYRP", style = MaterialTheme.typography.displaySmall)
                    Text("MOBILE ROLEPLAY", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(28.dp))
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(18.dp)) {
                            Text(if (server.online) "● Сервер онлайн" else "● Сервер офлайн", style = MaterialTheme.typography.titleLarge)
                            Text(if (server.online) "Игроков: ${server.players}/${server.maxPlayers}" else server.text)
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(18.dp)) {
                            Text("Версия игры", style = MaterialTheme.typography.titleLarge)
                            Text(manifest?.version ?: "Проверка обновлений…")
                            manifest?.let { Text("Размер APK: %.1f MB".format(it.sizeMb)) }
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                    Button(onClick = {
                        busy = true
                        message = "Проверяем обновление…"
                        kotlinx.coroutines.MainScope().launch(Dispatchers.IO) {
                            val m = fetchManifest()
                            withContext(Dispatchers.Main) {
                                manifest = m
                                busy = false
                                if (m == null) message = "Не удалось получить manifest.json"
                                else if (isGameInstalled()) launchGame() else message = "Игра не установлена — нажмите «Скачать игру»"
                            }
                        }
                    }, enabled = !busy && server.online, modifier = Modifier.fillMaxWidth().height(54.dp)) {
                        Text(if (isGameInstalled()) "ИГРАТЬ" else "СКАЧАТЬ ИГРУ")
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = {
                        manifest?.let { downloadGame(it); message = "Загрузка APK началась…" } ?: run { message = "Сначала обновите информацию" }
                    }, enabled = !busy && manifest != null, modifier = Modifier.fillMaxWidth().height(50.dp)) { Text("Скачать / обновить") }
                    Spacer(Modifier.height(16.dp))
                    Text(message)
                    Spacer(Modifier.height(30.dp))
                    Text("BlackCityRP • Android Launcher 1.0.0", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }

    private suspend fun fetchServer(): ServerState = withContext(Dispatchers.IO) {
        try {
            val c = URL(LauncherConfig.HEALTH_URL).openConnection() as HttpURLConnection
            c.connectTimeout = 5000; c.readTimeout = 5000
            if (c.responseCode != 200) return@withContext ServerState(false, text = "HTTP ${c.responseCode}")
            val o = JSONObject(c.inputStream.bufferedReader().readText())
            ServerState(o.optBoolean("ok"), o.optInt("players"), o.optInt("maxPlayers"), "Сервер отвечает")
        } catch (e: Exception) { ServerState(false, text = "Нет подключения") }
    }

    private suspend fun fetchManifest(): GameManifest? = withContext(Dispatchers.IO) {
        try {
            val c = URL(LauncherConfig.MANIFEST_URL).openConnection() as HttpURLConnection
            c.connectTimeout = 7000; c.readTimeout = 7000
            if (c.responseCode != 200) return@withContext null
            val o = JSONObject(c.inputStream.bufferedReader().readText())
            GameManifest(o.getString("version"), o.getInt("versionCode"), o.getString("apkUrl"), o.getString("sha256").lowercase(), o.optDouble("sizeMb", 0.0))
        } catch (_: Exception) { null }
    }

    private fun isGameInstalled(): Boolean = try { packageManager.getPackageInfo(LauncherConfig.GAME_PACKAGE, 0); true } catch (_: Exception) { false }

    private fun launchGame() {
        val intent = packageManager.getLaunchIntentForPackage(LauncherConfig.GAME_PACKAGE)
        if (intent != null) startActivity(intent)
    }

    private fun downloadGame(m: GameManifest) {
        val req = DownloadManager.Request(Uri.parse(m.apkUrl))
            .setTitle("BlackCityRP")
            .setDescription("Скачивание обновления игры")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, LauncherConfig.GAME_APK_NAME)
        downloadId = (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
        getSharedPreferences("launcher", MODE_PRIVATE).edit().putLong("download_id", downloadId).putString("sha256", m.sha256.lowercase()).apply()
    }

    companion object {
        fun sha256Static(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input -> val buf = ByteArray(8192); var n: Int; while (input.read(buf).also { n = it } > 0) digest.update(buf, 0, n) }
        return digest.digest().joinToString("") { "%02x".format(it) }
        }
    }
}
