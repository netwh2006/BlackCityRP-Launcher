package com.blackcityrp.launcher

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File

class DownloadReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != DownloadManager.ACTION_DOWNLOAD_COMPLETE) return
        val id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
        val prefs = context.getSharedPreferences("launcher", Context.MODE_PRIVATE)
        if (id != prefs.getLong("download_id", -2L)) return
        val file = File(context.getExternalFilesDir("Download"), LauncherConfig.GAME_APK_NAME)
        if (!file.exists()) return
        val expected = prefs.getString("sha256", "") ?: ""
        if (expected.isNotBlank() && expected.length == 64 && MainActivity.sha256Static(file) != expected.lowercase()) return
        val uri: Uri = FileProvider.getUriForFile(context, "com.blackcityrp.launcher.files", file)
        val install = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(install)
    }
}
